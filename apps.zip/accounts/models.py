from django.db import models

from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    ROLE_CHOICES = [
        ("ADMIN", "Admin"),
        ("PHARMACIST", "Pharmacist"),
        ("STOCK_CLERK", "Stock Clerk"),
        ("STORE_MANAGER", "Store Manager"),
    ]
    phone_number = models.CharField(max_length=15,unique=True,null=True,blank=True)
    role = models.CharField(max_length=20,choices=ROLE_CHOICES,default="STOCK_CLERK")


    def __str__(self):
        return self.username